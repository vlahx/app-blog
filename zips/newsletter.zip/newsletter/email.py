from __future__ import annotations

import logging
import os
import smtplib
import ssl
from collections.abc import Iterator
from contextlib import contextmanager
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid, parseaddr
from typing import Any

from app.core.config import SMTP_DEBUG, SMTP_SKIP_TLS_VERIFY, get_site_display_name
from app.core.plugin_manager import get_plugin_setting

logger = logging.getLogger(__name__)
_PLUGIN_ID = "newsletter"


def _chain_setting(key: str, env_key: str = "") -> str:
    val = get_plugin_setting(_PLUGIN_ID, key).strip()
    if val:
        return val
    if env_key:
        return os.environ.get(env_key, "").strip()
    return ""


def get_smtp_params() -> dict[str, Any] | None:
    host = _chain_setting("smtp_host", "NEWSLETTER_SMTP_HOST")
    if not host:
        return None
    port_raw = _chain_setting("smtp_port", "NEWSLETTER_SMTP_PORT") or "587"
    try:
        port = int(port_raw)
    except ValueError:
        port = 587
    user = _chain_setting("smtp_user", "NEWSLETTER_SMTP_USER")
    password = _chain_setting("smtp_password", "NEWSLETTER_SMTP_PASSWORD")
    from_addr = _chain_setting("from_email", "NEWSLETTER_FROM_EMAIL") or user
    if not from_addr:
        return None
    from_name = os.environ.get("NEWSLETTER_FROM_NAME", "").strip() or get_site_display_name()
    use_tls_raw = _chain_setting("smtp_use_tls", "NEWSLETTER_SMTP_STARTTLS")
    use_tls = use_tls_raw.lower() not in ("0", "false", "no", "off") if use_tls_raw else True

    allow_self_signed = _chain_setting("smtp_allow_self_signed", "NEWSLETTER_SMTP_TLS_VERIFY").lower() in ("1", "true", "yes", "on", "false", "0")

    if SMTP_SKIP_TLS_VERIFY or allow_self_signed:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    else:
        ctx = ssl.create_default_context()

    return {
        "host": host,
        "port": port,
        "user": user,
        "password": password,
        "from_addr": from_addr,
        "from_name": from_name,
        "use_tls": use_tls,
        "ctx": ctx,
    }


@contextmanager
def get_smtp_connection(p: dict[str, Any]) -> Iterator[smtplib.SMTP | smtplib.SMTP_SSL]:
    host = p["host"]
    port = p["port"]
    user = p["user"]
    password = p["password"]
    use_tls = p["use_tls"]
    ctx = p["ctx"]

    try:
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=ctx, timeout=60) as smtp:
                if SMTP_DEBUG:
                    smtp.set_debuglevel(1)
                if user and password:
                    smtp.login(user, password)
                yield smtp
        else:
            with smtplib.SMTP(host, port, timeout=60) as smtp:
                if SMTP_DEBUG:
                    smtp.set_debuglevel(1)
                smtp.ehlo()
                if use_tls:
                    smtp.starttls(context=ctx)
                    smtp.ehlo()
                if user and password:
                    smtp.login(user, password)
                yield smtp
    except Exception as e:
        logger.warning("Newsletter SMTP connection failed: %s", e)
        raise


def send_single_email(to_email: str, subject: str, body_text: str, body_html: str | None = None) -> bool:
    params = get_smtp_params()
    if not params:
        logger.warning("Newsletter SMTP not configured.")
        return False
    try:
        with get_smtp_connection(params) as smtp:
            msg = EmailMessage()
            msg["Subject"] = subject
            msg["From"] = formataddr((params["from_name"], params["from_addr"]))
            msg["To"] = to_email
            msg["Date"] = formatdate(localtime=True)
            msg["Message-ID"] = make_msgid()
            msg.set_content(body_text)
            if body_html:
                msg.add_alternative(body_html, subtype="html")
            smtp.send_message(msg)
            return True
    except Exception as e:
        logger.warning("Failed sending email to %s: %s", to_email, e)
        return False


def broadcast_newsletter(subject: str, deliveries: list[tuple[str, str, str, str]]) -> int:
    """
    Trimite e-mailuri de masă către lista de abonați.
    deliveries: list of (email, text_plain, html_body, unsubscribe_url)
    """
    params = get_smtp_params()
    if not params or not deliveries:
        return 0
    count = 0
    try:
        with get_smtp_connection(params) as smtp:
            for em, text_plain, html_body, unsub_url in deliveries:
                try:
                    msg = EmailMessage()
                    msg["Subject"] = subject
                    msg["From"] = formataddr((params["from_name"], params["from_addr"]))
                    msg["To"] = em
                    msg["Date"] = formatdate(localtime=True)
                    msg["Message-ID"] = make_msgid()
                    if unsub_url:
                        msg["List-Unsubscribe"] = f"<{unsub_url}>"
                        msg["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"
                    msg.set_content(text_plain)
                    if html_body:
                        msg.add_alternative(html_body, subtype="html")
                    smtp.send_message(msg)
                    count += 1
                except Exception as ex:
                    logger.warning("Error sending broadcast to %s: %s", em, ex)
    except Exception as e:
        logger.warning("Broadcast SMTP session failed: %s", e)
    return count
