from __future__ import annotations

import logging
import csv
import io
import re
from html import escape
from urllib.parse import quote

from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from jinja2 import Environment, FileSystemLoader, select_autoescape

from app.core.config import PROJECT_ROOT, get_site_display_name
from app.core.events import publish, subscribe
from app.core.i18n import get_translation, resolve_locale, get_plugin_translation
from app.core.plugin_manager import get_plugin_setting
from app.utils.auth import get_current_user_from_request, user_has_role

def require_admin_user(request: Request) -> None:
    user = getattr(request.state, "current_user", None) or get_current_user_from_request(request)
    if not user or not user_has_role(user, "admin"):
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Acces interzis.")

from app.plugins.newsletter.db import (
    init_newsletter_db,
    add_or_reactivate_subscriber,
    unsubscribe_email,
    set_subscriber_status,
    delete_subscriber,
    list_active_subscribers,
    list_all_subscribers,
    normalize_email,
)
from app.plugins.newsletter.tokens import make_unsubscribe_token, parse_unsubscribe_token, public_unsubscribe_url
from app.plugins.newsletter.email import send_single_email, broadcast_newsletter

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
logger = logging.getLogger(__name__)


def _jinja_env() -> Environment:
    tpl_dir = PROJECT_ROOT / "plugins" / "newsletter" / "templates" / "email"
    if not tpl_dir.exists():
        tpl_dir.mkdir(parents=True, exist_ok=True)
    return Environment(
        loader=FileSystemLoader(str(tpl_dir)),
        autoescape=select_autoescape(["html", "xml"]),
    )


def register(app: FastAPI, plugin_id: str = "newsletter") -> None:
    init_newsletter_db()

    @app.get("/newsletter", include_in_schema=False)
    async def newsletter_get(request: Request, ok: str | None = None, err: str | None = None):
        return RedirectResponse(url="/?newsletter_ok=1" if ok == "1" else "/", status_code=303)

    @app.get("/newsletter/unsubscribe", include_in_schema=False)
    async def newsletter_unsubscribe_get(request: Request, t: str | None = None):
        if not t or not str(t).strip():
            q = quote("Link de dezabonare invalid.", safe="")
            return RedirectResponse(url=f"/?newsletter_err={q}", status_code=303)
        
        email = parse_unsubscribe_token(str(t).strip())
        if not email:
            q = quote("Link de dezabonare expirat sau invalid.", safe="")
            return RedirectResponse(url=f"/?newsletter_err={q}", status_code=303)
        
        unsubscribe_email(email)
        return RedirectResponse(url="/?newsletter_unsub=1", status_code=303)

    @app.post("/newsletter/subscribe", include_in_schema=False)
    async def newsletter_subscribe(request: Request):
        form = await request.form()
        referer = request.headers.get("referer") or "/"
        is_ajax = request.headers.get("x-requested-with") == "XMLHttpRequest" or "json" in request.headers.get("accept", "").lower()
        
        loc = getattr(request.state, "locale", None) or resolve_locale(request)
        success_msg = get_plugin_translation("newsletter", loc, "success", "Mulțumim pentru abonare! Te rugăm să verifici și folderul Spam pentru e-mailurile viitoare.")
        already_msg = get_plugin_translation("newsletter", loc, "already_subscribed", "Această adresă de e-mail este deja abonată la newsletter.")
        err_invalid = get_plugin_translation("newsletter", loc, "error", "Adresă de e-mail invalidă.")
        blocked_msg = get_plugin_translation("newsletter", loc, "blocked", "Această adresă de e-mail nu poate fi abonată.")

        # Honeypot check
        if (form.get("company") or "").strip():
            if is_ajax:
                return JSONResponse({"ok": True, "msg": success_msg, "is_new": True})
            return RedirectResponse(url=f"{referer}?newsletter_ok=1", status_code=303)

        raw = form.get("email") or ""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        email = normalize_email(str(raw))
        if not email or not _EMAIL_RE.match(email):
            if is_ajax:
                return JSONResponse({"ok": False, "err": err_invalid}, status_code=400)
            q = quote(err_invalid, safe="")
            return RedirectResponse(url=f"{referer}?newsletter_err={q}", status_code=303)

        result = add_or_reactivate_subscriber(email, locale=loc)
        sep = "&" if "?" in referer else "?"

        if result in ("new", "reactivated"):
            publish("newsletter.subscribed", email=email, is_new=(result == "new"))
            
            # Send notification notice if configured
            notify_email = get_plugin_setting(plugin_id, "notify_email").strip()
            if notify_email:
                send_single_email(
                    to_email=notify_email,
                    subject=f"Abonat nou la newsletter: {email}",
                    body_text=f"Abonat nou pe {get_site_display_name()}: {email} (Limba: {loc})",
                )

            if is_ajax:
                return JSONResponse({"ok": True, "msg": success_msg, "is_new": True})
            return RedirectResponse(url=f"{referer}{sep}newsletter_ok=1", status_code=303)
        elif result == "blocked":
            if is_ajax:
                return JSONResponse({"ok": False, "err": blocked_msg}, status_code=403)
            q = quote(blocked_msg, safe="")
            return RedirectResponse(url=f"{referer}{sep}newsletter_err={q}", status_code=303)
        else:
            if is_ajax:
                return JSONResponse({"ok": True, "msg": already_msg, "is_new": False, "is_already": True})
            return RedirectResponse(url=f"{referer}{sep}newsletter_already=1", status_code=303)

    # ADMIN: Subscribers Management Page
    @app.get("/admin/newsletter", include_in_schema=False)
    @app.get("/admin/plugins/newsletter/subscribers", include_in_schema=False)
    async def admin_newsletter_subscribers(request: Request):
        require_admin_user(request)
        subscribers = list_all_subscribers()
        from app.core.templates import build_templates, render_template
        templates = build_templates()
        
        return render_template(
            templates,
            request=request,
            name="admin/newsletter_subscribers.html",
            context={
                "title": "Abonați Newsletter",
                "subscribers": subscribers,
                "total_count": len(subscribers),
                "active_count": sum(1 for s in subscribers if s["status"] == "active"),
                "blocked_count": sum(1 for s in subscribers if s["status"] == "blocked"),
                "unsubscribed_count": sum(1 for s in subscribers if s["status"] == "unsubscribed"),
            },
        )

    # ADMIN: Subscriber Actions (Block / Activate / Delete)
    @app.post("/admin/plugins/newsletter/subscribers/action", include_in_schema=False)
    async def admin_newsletter_subscriber_action(
        request: Request,
        email: str = Form(...),
        action: str = Form(...),
    ):
        require_admin_user(request)
        email = normalize_email(email)
        
        if action == "block":
            set_subscriber_status(email, "blocked")
            msg = f"Adresa {email} a fost blocată."
        elif action == "activate":
            set_subscriber_status(email, "active")
            msg = f"Adresa {email} a fost activată."
        elif action == "unsubscribe":
            set_subscriber_status(email, "unsubscribed")
            msg = f"Adresa {email} a fost dezabonată."
        elif action == "delete":
            delete_subscriber(email)
            msg = f"Adresa {email} a fost ștearsă din baza de date."
        else:
            msg = "Acțiune necunoscută."

        q = quote(msg, safe="")
        return RedirectResponse(url=f"/admin/plugins/newsletter/subscribers?msg={q}", status_code=303)

    # ADMIN: Export Subscribers CSV
    @app.get("/admin/plugins/newsletter/subscribers/export", include_in_schema=False)
    async def admin_newsletter_export_csv(request: Request):
        require_admin_user(request)
        subscribers = list_all_subscribers()
        
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["ID", "Email", "Locale", "Status", "Subscribed At", "Unsubscribed At"])
        for s in subscribers:
            writer.writerow([s["id"], s["email"], s["locale"], s["status"], s["subscribed_at"], s["unsubscribed_at"]])
        
        content = output.getvalue()
        output.close()
        
        return Response(
            content=content,
            media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="newsletter_subscribers.csv"'},
        )

    # EVENT: Broadcast newsletter when a new blog post is published
    def on_blog_post_published(
        slug: str = "",
        title: str = "",
        excerpt: str = "",
        post_url: str = "",
        hero_image_abs: str | None = None,
        translations: dict[str, dict[str, str]] | None = None,
        **kwargs: object,
    ) -> None:
        opt = get_plugin_setting(plugin_id, "email_subscribers_on_publish").strip().lower()
        if opt in ("0", "false", "no", "off"):
            logger.info("newsletter: skip broadcast pentru %r — dezactivat în setări.", slug)
            return

        subscribers = list_active_subscribers()
        if not subscribers:
            logger.info("newsletter: skip broadcast pentru %r — nu există abonați activi.", slug)
            return

        trans_map = translations or {}
        site_label = get_site_display_name()
        
        try:
            tpl = _jinja_env().get_template("newsletter_new_post.html")
        except Exception:
            tpl = None

        deliveries: list[tuple[str, str, str, str]] = []

        for sub in subscribers:
            em = sub["email"]
            sub_loc = sub.get("locale", "ro")
            
            sub_trans = trans_map.get(sub_loc) or trans_map.get("ro") or {}
            sub_title = (sub_trans.get("title") or title or slug).strip()
            sub_excerpt = (sub_trans.get("excerpt") or excerpt or "").strip()

            tok = make_unsubscribe_token(em)
            unsub = public_unsubscribe_url(tok)
            
            if tpl:
                html_content = tpl.render(
                    site_label=site_label,
                    post_title=sub_title,
                    post_url=post_url,
                    hero_abs=hero_image_abs or "",
                    excerpt=sub_excerpt,
                    unsub_url=unsub,
                )
            else:
                html_content = f"<h2>{escape(sub_title)}</h2><p>{escape(sub_excerpt)}</p><p><a href='{post_url}'>Citește articolul</a></p><hr/><p><small><a href='{unsub}'>Dezabonare</a></small></p>"

            text_plain = f"{sub_title}\n\n{sub_excerpt}\n\nCitește: {post_url}\n\n—\nDezabonare: {unsub}\n"
            deliveries.append((em, text_plain, html_content, unsub))

        default_title = (title or slug).strip()
        main_subject = f"Articol nou: {default_title}"
        n = broadcast_newsletter(subject=main_subject, deliveries=deliveries)
        logger.info("newsletter: trimis cu succes către %s/%s abonați pentru %r.", n, len(subscribers), slug)

    subscribe("blog.post_published", on_blog_post_published)

    def render_newsletter_admin_nav(request: Request) -> str:
        return '<li class="nav-item"><a class="nav-link fw-semibold px-3 rounded-2" href="/admin/newsletter">📧 Newsletter</a></li>'

    def render_newsletter_admin_top_bar(request: Request) -> str:
        return '<a class="btn btn-sm btn-outline-primary fw-semibold me-2" href="/admin/newsletter">📧 Moderare Abonați Newsletter</a>'

    from app.core.template_hooks import register_admin_nav, register_admin_top_bar
    register_admin_nav(render_newsletter_admin_nav)
    register_admin_top_bar(render_newsletter_admin_top_bar)
