from __future__ import annotations

import base64
import hashlib
import hmac
import time
from urllib.parse import quote

from app.core.config import SESSION_SECRET, PUBLIC_SITE_URL
from app.utils.open_graph import public_site_origin

def _secret_bytes() -> bytes:
    key = (SESSION_SECRET or "fallback-newsletter-key-change-me").strip()
    return key.encode("utf-8")


def make_unsubscribe_token(email: str) -> str:
    """Generează token securizat HMAC pentru dezabonare 1-click."""
    norm = " ".join(email.split()).strip().lower()
    msg = f"unsub:{norm}".encode("utf-8")
    sig = hmac.new(_secret_bytes(), msg, hashlib.sha256).digest()
    raw = norm.encode("utf-8") + b"|" + sig
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def parse_unsubscribe_token(token: str) -> str | None:
    """Validează token-ul de dezabonare și returnează adresa de e-mail dacă este valid."""
    if not token or not token.strip():
        return None
    t = token.strip()
    padding = (4 - len(t) % 4) % 4
    t_padded = t + "=" * padding
    try:
        data = base64.urlsafe_b64decode(t_padded.encode("ascii"))
        parts = data.split(b"|", 1)
        if len(parts) != 2:
            return None
        email_bytes, sig = parts
        email = email_bytes.decode("utf-8", errors="ignore").strip().lower()
        if not email or "@" not in email:
            return None
        expected = hmac.new(_secret_bytes(), f"unsub:{email}".encode("utf-8"), hashlib.sha256).digest()
        if hmac.compare_digest(sig, expected):
            return email
    except Exception:
        pass
    return None


def public_unsubscribe_url(token: str) -> str:
    base = PUBLIC_SITE_URL.rstrip("/") if PUBLIC_SITE_URL else ""
    return f"{base}/newsletter/unsubscribe?t={quote(token, safe='')}"
