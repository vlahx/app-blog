from __future__ import annotations

import os
import sqlite3
import logging
from datetime import datetime, timezone

from app.utils.db import DB_PATH

logger = logging.getLogger(__name__)


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_newsletter_db() -> None:
    """Creează tabela newsletter_subscribers dacă nu există."""
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS newsletter_subscribers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                locale TEXT DEFAULT 'ro',
                status TEXT DEFAULT 'active',
                subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                unsubscribed_at TIMESTAMP NULL
            );
        """)
        conn.commit()


def normalize_email(raw: str) -> str:
    return " ".join(raw.split()).strip().lower()


def add_or_reactivate_subscriber(email: str, locale: str = "ro") -> str:
    """
    Adaugă sau actualizează un abonat.
    Returnează: 'new', 'reactivated', 'already_subscribed', sau 'blocked'.
    """
    init_newsletter_db()
    email = normalize_email(email)
    if not email:
        return "invalid"

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT status FROM newsletter_subscribers WHERE email = ?", (email,))
        row = cursor.fetchone()

        if row is None:
            cursor.execute(
                "INSERT INTO newsletter_subscribers (email, locale, status, subscribed_at) VALUES (?, ?, 'active', CURRENT_TIMESTAMP)",
                (email, locale),
            )
            conn.commit()
            return "new"
        
        status = row["status"]
        if status == "blocked":
            return "blocked"
        elif status == "unsubscribed":
            cursor.execute(
                "UPDATE newsletter_subscribers SET status = 'active', locale = ?, unsubscribed_at = NULL WHERE email = ?",
                (locale, email),
            )
            conn.commit()
            return "reactivated"
        else:
            return "already_subscribed"


def unsubscribe_email(email: str) -> bool:
    """Marchează un abonat ca dezabonat (status = 'unsubscribed')."""
    init_newsletter_db()
    email = normalize_email(email)
    if not email:
        return False
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE newsletter_subscribers SET status = 'unsubscribed', unsubscribed_at = CURRENT_TIMESTAMP WHERE email = ?",
            (email,),
        )
        conn.commit()
        return cursor.rowcount > 0


def set_subscriber_status(email: str, new_status: str) -> bool:
    """Schimbă statusul unui abonat ('active', 'blocked', 'unsubscribed')."""
    init_newsletter_db()
    email = normalize_email(email)
    if new_status not in ("active", "blocked", "unsubscribed"):
        return False
    with get_connection() as conn:
        cursor = conn.cursor()
        if new_status == "unsubscribed":
            cursor.execute(
                "UPDATE newsletter_subscribers SET status = ?, unsubscribed_at = CURRENT_TIMESTAMP WHERE email = ?",
                (new_status, email),
            )
        else:
            cursor.execute(
                "UPDATE newsletter_subscribers SET status = ? WHERE email = ?",
                (new_status, email),
            )
        conn.commit()
        return cursor.rowcount > 0


def delete_subscriber(email: str) -> bool:
    """Șterge definitiv un abonat din baza de date."""
    init_newsletter_db()
    email = normalize_email(email)
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM newsletter_subscribers WHERE email = ?", (email,))
        conn.commit()
        return cursor.rowcount > 0


def list_active_subscribers() -> list[dict[str, str]]:
    """Returnează doar abonații activi pentru trimitere e-mailuri."""
    init_newsletter_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT email, locale FROM newsletter_subscribers WHERE status = 'active' ORDER BY id ASC")
        return [{"email": row["email"], "locale": row["locale"] or "ro"} for row in cursor.fetchall()]


def list_all_subscribers() -> list[dict[str, str]]:
    """Returnează toți abonații pentru panoul de administrare."""
    init_newsletter_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, email, locale, status, subscribed_at, unsubscribed_at FROM newsletter_subscribers ORDER BY id DESC")
        result = []
        for row in cursor.fetchall():
            result.append({
                "id": str(row["id"]),
                "email": row["email"],
                "locale": row["locale"] or "ro",
                "status": row["status"] or "active",
                "subscribed_at": str(row["subscribed_at"] or ""),
                "unsubscribed_at": str(row["unsubscribed_at"] or ""),
            })
        return result
