from __future__ import annotations
import json
import json

import logging
import re
from html import escape

from fastapi import Depends, FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from sqlalchemy.orm import Session

from app.core.i18n import get_plugin_translation, resolve_locale
from app.core.template_hooks import (
    register_admin_nav,
    register_admin_top_bar,
    register_footer_col4,
    register_post_article_footer,
    register_post_header_meta,
)
from app.core.templates import build_templates, render_template
from app.routers.admin import role_required
from app.utils.db import get_db

from app.plugins.analytics.db import (
    get_all_analytics,
    get_article_analytics,
    get_total_site_views,
    record_ping,
)

logger = logging.getLogger(__name__)
_HTML_TAG_RE = re.compile(r"<[^>]+>", re.S)


def _strip_tags(text: str) -> str:
    return _HTML_TAG_RE.sub("", text or "").strip()


def register(app: FastAPI, plugin_id: str = "analytics") -> None:
    @app.post("/api/analytics/ping", include_in_schema=False)
    async def analytics_ping(request: Request):
        data = {}
        try:
            body_bytes = await request.body()
            if body_bytes:
                data = json.loads(body_bytes.decode("utf-8"))
        except Exception:
            pass
        if not data:
            try:
                data = await request.json()
            except Exception:
                return JSONResponse({"ok": False}, status_code=400)

        slug = str(data.get("slug") or "").strip()
        seconds = int(data.get("seconds") or 0)
        is_new_view = bool(data.get("is_new_view"))
        seconds = max(0, min(30, seconds))

        if slug:
            record_ping(slug, seconds=seconds, is_new_view=is_new_view)

        return JSONResponse({"ok": True})

    @app.get("/admin/analytics", response_class=HTMLResponse)
    @role_required("admin")
    async def admin_analytics(request: Request, db: Session = Depends(get_db)):
        from app.core.posts_db import list_posts

        locale = getattr(request.state, "locale", None) or resolve_locale(request)
        posts = list_posts(db, include_drafts=True)
        stats = get_all_analytics()
        stats_by_slug = {s["slug"]: s for s in stats}

        items = []
        total_views = 0
        total_seconds_all = 0

        for p in posts:
            s = stats_by_slug.get(p.slug, {"views": 0, "total_seconds": 0, "avg_seconds": 0})
            v = s["views"]
            tot_sec = s["total_seconds"]
            avg_sec = s["avg_seconds"]

            total_views += v
            total_seconds_all += tot_sec

            words = len(_strip_tags(p.content_html).split())
            est_min = max(1, round(words / 200))

            avg_m = avg_sec // 60
            avg_s = avg_sec % 60
            avg_str = f"{avg_m}m {avg_s}s" if avg_m > 0 else f"{avg_s}s"

            tot_m = tot_sec // 60
            tot_s = tot_sec % 60
            tot_str = f"{tot_m}m {tot_s}s" if tot_m > 0 else f"{tot_s}s"

            items.append({
                "title": p.title,
                "slug": p.slug,
                "type": "post",
                "url": f"/blog/{p.slug}",
                "edit_url": f"/admin/edit/{p.slug}",
                "draft": p.draft,
                "views": v,
                "total_seconds": tot_sec,
                "avg_seconds": avg_sec,
                "avg_str": avg_str,
                "tot_str": tot_str,
                "est_min": est_min,
                "info": f"/{p.slug} • {words} cuvinte",
            })

        # Include Shop Products if minishop plugin is active
        try:
            from app.core.plugin_manager import is_plugin_enabled
            if is_plugin_enabled("minishop"):
                from app.plugins.minishop.db import list_shop_products
                products = list_shop_products(active_only=False)
                for prod in products:
                    pslug = prod.get("slug") or ""
                    if not pslug:
                        continue
                    s = stats_by_slug.get(pslug, {"views": 0, "total_seconds": 0, "avg_seconds": 0})
                    v = s["views"]
                    tot_sec = s["total_seconds"]
                    avg_sec = s["avg_seconds"]

                    total_views += v
                    total_seconds_all += tot_sec

                    avg_m = avg_sec // 60
                    avg_s = avg_sec % 60
                    avg_str = f"{avg_m}m {avg_s}s" if avg_m > 0 else f"{avg_s}s"

                    tot_m = tot_sec // 60
                    tot_s = tot_sec % 60
                    tot_str = f"{tot_m}m {tot_s}s" if tot_m > 0 else f"{tot_s}s"

                    price = prod.get("price", 0.0)
                    curr = prod.get("currency", "RON")

                    items.append({
                        "title": prod.get("title") or pslug,
                        "slug": pslug,
                        "type": "product",
                        "url": f"/shop/product/{pslug}",
                        "edit_url": "/admin/minishop",
                        "draft": not bool(prod.get("is_active")),
                        "views": v,
                        "total_seconds": tot_sec,
                        "avg_seconds": avg_sec,
                        "avg_str": avg_str,
                        "tot_str": tot_str,
                        "est_min": 1,
                        "info": f"/{pslug} • {price:.2f} {curr}",
                    })
        except Exception as e:
            logger.warning(f"Error loading shop products in analytics: {e}")

        items.sort(key=lambda x: x["views"], reverse=True)
        tot_min_str = f"{round(total_seconds_all / 60, 1)} min"

        templates = build_templates()
        return render_template(
            templates,
            request=request,
            name="admin/analytics.html",
            context={
                "title": get_plugin_translation("analytics", locale, "nav_button", "Statistici Vizualizări"),
                "total_views": total_views,
                "tot_min_str": tot_min_str,
                "total_items_count": len(items),
                "items": items,
            },
            status_code=200,
        )

    # 1. Admin Sub-Navbar Action Button
    def _admin_top_bar_analytics(_request: Request) -> str:
        loc = getattr(_request.state, "locale", None) or resolve_locale(_request)
        btn_text = get_plugin_translation("analytics", loc, "nav_button", "Statistici Vizualizări")
        return f'<a href="/admin/analytics" class="btn btn-sm btn-outline-primary fw-bold rounded-pill px-3 shadow-sm d-inline-flex align-items-center gap-1"><span>📊</span><span>{escape(btn_text)}</span></a>'

    def _admin_nav_analytics(_request: Request) -> str:
        loc = getattr(_request.state, "locale", None) or resolve_locale(_request)
        btn_text = get_plugin_translation("analytics", loc, "nav_button", "Statistici Vizualizări")
        return f"<a href=\"/admin/analytics\" class=\"nav-link text-white fw-semibold d-flex align-items-center gap-2 px-3 py-2 rounded\"><span>📊</span><span>{escape(btn_text)}</span></a>"

    register_admin_nav(_admin_nav_analytics, order=20)
    register_admin_top_bar(_admin_top_bar_analytics, order=20)

    # 2. Post Page Header Meta & Beacon Script
    def _header_meta_analytics(_post: object, _request: Request) -> str:
        slug = getattr(_post, "slug", "")
        if not slug:
            return ""

        loc = getattr(_request.state, "locale", None) or resolve_locale(_request)
        content_html = getattr(_post, "content_html", "") or ""
        words = len(_strip_tags(content_html).split())
        est_min = max(1, round(words / 200))

        stats = get_article_analytics(slug)
        views = stats["views"]

        views_label = get_plugin_translation("analytics", loc, "views", "vizualizări")
        read_label = get_plugin_translation("analytics", loc, "read_time", "min citire")

        return f'''<span class="badge bg-secondary bg-opacity-75 d-inline-flex align-items-center gap-1" title="Număr vizualizări"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>{views} {views_label}</span> <span class="badge bg-secondary bg-opacity-75 d-inline-flex align-items-center gap-1" title="Timp estimat de lectură"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>{est_min} {read_label}</span><script>(function(){{const slug="{slug}";const sessionKey="viewed_"+slug;const isNewView=!sessionStorage.getItem(sessionKey);if(isNewView){{sessionStorage.setItem(sessionKey,"1");}}let startTime=Date.now();function ping(seconds,isNew){{if(seconds<=0&&!isNew)return;const payload=JSON.stringify({{slug:slug,seconds:seconds,is_new_view:isNew}});try{{if(navigator.sendBeacon){{navigator.sendBeacon("/api/analytics/ping",payload);}}else{{fetch("/api/analytics/ping",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:payload,keepalive:true}});}}}}catch(e){{}}}}ping(0,isNewView);setInterval(function(){{if(!document.hidden){{const now=Date.now();const elapsed=Math.round((now-startTime)/1000);if(elapsed>=5){{startTime=now;ping(elapsed,false);}}}},5000);function sendExitPing(){{if(!document.hidden){{const now=Date.now();const elapsed=Math.round((now-startTime)/1000);if(elapsed>0){{startTime=now;ping(elapsed,false);}}}}}}window.addEventListener("visibilitychange",function(){{if(document.hidden)sendExitPing();}});window.addEventListener("pagehide",sendExitPing);window.addEventListener("beforeunload",sendExitPing);}})();</script>'''

    register_post_header_meta(_header_meta_analytics, order=10)

    # 3. Blog List Post Card Counter Badge
    def _post_card_analytics_footer(_post: object, _request: Request) -> str:
        slug = getattr(_post, "slug", "")
        if not slug:
            return ""
        loc = getattr(_request.state, "locale", None) or resolve_locale(_request)
        stats = get_article_analytics(slug)
        views = stats["views"]
        views_label = get_plugin_translation("analytics", loc, "views", "vizualizări")
        return f'<div class="mt-2 text-secondary small d-flex align-items-center gap-1" style="font-size:0.8rem;"><span class="opacity-75">👁️</span> <span>{views} {views_label}</span></div>'

    register_post_article_footer(_post_card_analytics_footer, order=10)

    # 4. Footer Column 4 Total Site Views Counter
    def _footer_analytics_views(_request: Request) -> str:
        loc = getattr(_request.state, "locale", None) or resolve_locale(_request)
        total_views = get_total_site_views()
        total_label = get_plugin_translation("analytics", loc, "footer_total_views", "vizualizări totale site")
        return f'<div class="mt-3 pt-2 border-top border-secondary border-opacity-25 text-secondary small fw-semibold d-flex align-items-center gap-1"><span class="fs-6">👁️</span><span>{total_views:,} {escape(total_label)}</span></div>'

    register_footer_col4(_footer_analytics_views, order=10)