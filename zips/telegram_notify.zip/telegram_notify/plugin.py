from __future__ import annotations

import logging
from typing import Any
from fastapi import FastAPI

from app.core.events import subscribe
from app.core.plugin_manager import get_plugin_setting, is_plugin_enabled
from app.plugins.telegram_notify.sender import send_telegram_message

logger = logging.getLogger(__name__)


def register(_app: FastAPI, plugin_id: str = "telegram_notify") -> None:
    def _get_credentials() -> tuple[str | None, str | None]:
        bot_token = str(get_plugin_setting(plugin_id, "bot_token", "") or "").strip() or None
        chat_id = str(get_plugin_setting(plugin_id, "chat_id", "") or "").strip() or None
        return bot_token, chat_id

    # 1. User nou înregistrat
    def on_user_registered(provider: str = "local", email: str = "", first_name: str = "", last_name: str = "", username: str = "", **kwargs: Any) -> None:
        if not is_plugin_enabled(plugin_id):
            return
        if not get_plugin_setting(plugin_id, "notify_users", True):
            return
        
        user_disp = f"{first_name} {last_name}".strip() or username or email or "Utilizator Nou"
        
        text = f"👤 Utilizator nou înregistrat!\nNume: {user_disp}\nMetodă: {provider.upper()}\nEmail: {email}"
        bot_token, chat_id = _get_credentials()
        send_telegram_message(text, bot_token=bot_token, chat_id=chat_id)

    # 2. Abonare Newsletter
    def on_newsletter_subscribed(email: str = "", is_new: bool = False, **kwargs: Any) -> None:
        if not is_plugin_enabled(plugin_id) or not is_new:
            return
        if not get_plugin_setting(plugin_id, "notify_newsletter", True):
            return

        text = f"📧 Newsletter — Abonare nouă!\nEmail: {email}"
        bot_token, chat_id = _get_credentials()
        send_telegram_message(text, bot_token=bot_token, chat_id=chat_id)

    # 3. Articol Nou Publicat
    def on_post_published(slug: str = "", title: str = "", post_url: str = "", excerpt: str = "", **kwargs: Any) -> None:
        if not is_plugin_enabled(plugin_id):
            return
        if not get_plugin_setting(plugin_id, "notify_posts", True):
            return

        disp_title = title or slug
        text = f"📝 Articol nou publicat!\nTitlu: {disp_title}\nLink: {post_url}"
        bot_token, chat_id = _get_credentials()
        send_telegram_message(text, bot_token=bot_token, chat_id=chat_id)

    # 4. Comentariu Nou
    def on_comment_created(author: str = "Anonim", post_title: str = "", content: str = "", **kwargs: Any) -> None:
        if not is_plugin_enabled(plugin_id):
            return
        if not get_plugin_setting(plugin_id, "notify_comments", True):
            return

        text = f"💬 Comentariu nou!\nAutor: {author}\nArticol: {post_title}\nText: {content[:200]}"
        bot_token, chat_id = _get_credentials()
        send_telegram_message(text, bot_token=bot_token, chat_id=chat_id)

    # 5. Comandă Nouă în Magazin
    def on_order_created(order_number: str = "", customer_name: str = "", customer_email: str = "", total_amount: float = 0.0, currency: str = "RON", payment_method: str = "stripe", **kwargs: Any) -> None:
        if not is_plugin_enabled(plugin_id):
            return
        if not get_plugin_setting(plugin_id, "notify_orders", True):
            return

        text = f"🛒 Comandă nouă în Magazin! (#{order_number})\nClient: {customer_name} ({customer_email})\nTotal: {total_amount:.2f} {currency}\nPlată: {payment_method.upper()}"
        bot_token, chat_id = _get_credentials()
        send_telegram_message(text, bot_token=bot_token, chat_id=chat_id)

    # 6. Recenzie Nouă Produs
    def on_review_added(product_title: str = "", rating: int = 5, user_name: str = "Anonim", **kwargs: Any) -> None:
        if not is_plugin_enabled(plugin_id):
            return
        if not get_plugin_setting(plugin_id, "notify_reviews", True):
            return

        stars = "⭐" * min(max(int(rating), 1), 5)
        text = f"⭐ Recenzie nouă produs!\nProdus: {product_title}\nNota: {stars} ({rating}/5)\nAutor: {user_name}"
        bot_token, chat_id = _get_credentials()
        send_telegram_message(text, bot_token=bot_token, chat_id=chat_id)

    # Înregistrare Handler-e evenimente
    subscribe("user.registered", on_user_registered)
    subscribe("newsletter.subscribed", on_newsletter_subscribed)
    subscribe("blog.post_published", on_post_published)
    subscribe("comments.created", on_comment_created)
    subscribe("shop.order_created", on_order_created)
    subscribe("shop.review_added", on_review_added)
